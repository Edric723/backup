
data Nave = N (Map SectorId Sector) (Map Nombre Tripulante) (MaxHeap Tripulante)
deriving Show

data Componente = LanzaTorpedos | Motor Int | Almacen [Barril]
deriving Show

data Barril = Comida | Oxigeno | Torpedo | Combustible
deriving Show


-- Observaciones: 
                    --Pueden existir sectores sin tripulantes, los cuales se los considera vacíos.
                    --Pueden existir tripulantes sin sectores asignados.

-- INV. REP.: 
                    --Todos los tripulantes son únicos, es decir no hay tripulantes repetidos.
                    --Todos los sectores son únicos
                    -- Si un tripulante aparece como valor en mnt, debe aparecer en la heap (ht)
                    -- Si aparece un tripulante en la heap, debe aparecer como valor en mnt.


                    -- un tripulante como valor en el segundo map tiene q estar en el heap
                    -- si hay un tripulante en la heap tiene q estar como valor en el 2do map
                    -- el nombre como clave del 2do map tiene que estar asociada a un tripulante.
                    -- la clave del primer map esta asociada a un sector esa calve pertenece a dicho sector.
                    -- el sector del tripulante en ht debe estar como valor del mss.

--b) construir :: [SectorId] -> Nave
--Propósito: Construye una nave con sectores vacíos, en base a una lista de identificadores de sectores.
--Eficiencia: O(S)