Set, siendo N la cantidad de elementos del conjunto:
emptyS :: Set a O(1)
addS :: a -> Set a -> Set a O(log N )
belongsS :: a -> Set a -> Bool O(log N )
unionS :: Set a -> Set a -> Set a O(N log N )
setToList :: Set a -> [a] O(N )
sizeS :: Set a -> Int O(1)