tipos abstractos de datos en haskell, stack, queue, set, multisets, maps, priority queue, heaps, bsts y avls. Necesito que me armes una guia de estudio con explicaciones ejemplos, explicaciones detalladas y comprensibles.
ChatGPT Plus
ChatGPT
¡Claro! A continuación te presento una guía de estudio sobre varios tipos abstractos de datos (TAD) en Haskell. Esta guía incluye definiciones, explicaciones, ejemplos y detalles sobre cada tipo de dato.

Guía de Estudio de Tipos Abstractos de Datos en Haskell
1. Stack (Pila)
Definición: Una pila es una estructura de datos que sigue el principio LIFO (Last In, First Out). Esto significa que el último elemento añadido es el primero en ser eliminado.

Operaciones principales:

push: Agrega un elemento a la pila.
pop: Elimina el elemento superior de la pila.
peek: Devuelve el elemento superior sin eliminarlo.
isEmpty: Verifica si la pila está vacía.
Ejemplo en Haskell:

haskell
Copiar código
data Stack a = Stack [a] deriving Show

push :: a -> Stack a -> Stack a
push x (Stack xs) = Stack (x:xs)

pop :: Stack a -> (a, Stack a)
pop (Stack (x:xs)) = (x, Stack xs)

peek :: Stack a -> a
peek (Stack (x:_)) = x

isEmpty :: Stack a -> Bool
isEmpty (Stack []) = True
isEmpty _ = False
2. Queue (Cola)
Definición: Una cola es una estructura de datos que sigue el principio FIFO (First In, First Out). El primer elemento añadido es el primero en ser eliminado.

Operaciones principales:

enqueue: Agrega un elemento al final de la cola.
dequeue: Elimina el primer elemento de la cola.
front: Devuelve el primer elemento sin eliminarlo.
isEmpty: Verifica si la cola está vacía.
Ejemplo en Haskell:

haskell
Copiar código
data Queue a = Queue [a] [a] deriving Show

enqueue :: a -> Queue a -> Queue a
enqueue x (Queue inQueue outQueue) = Queue (x:inQueue) outQueue

dequeue :: Queue a -> (a, Queue a)
dequeue (Queue [] []) = error "Empty Queue"
dequeue (Queue inQueue (x:outQueue)) = (x, Queue inQueue outQueue)
dequeue (Queue inQueue []) = dequeue (Queue [] (reverse inQueue))

front :: Queue a -> a
front (Queue [] []) = error "Empty Queue"
front (Queue _ (x:outQueue)) = x
front (Queue inQueue []) = head (reverse inQueue)
3. Set (Conjunto)
Definición: Un conjunto es una colección de elementos únicos, donde no importa el orden.

Operaciones principales:

insert: Añade un elemento al conjunto.
delete: Elimina un elemento del conjunto.
member: Verifica si un elemento pertenece al conjunto.
isEmpty: Verifica si el conjunto está vacío.
Ejemplo en Haskell:

haskell
Copiar código
import qualified Data.Set as Set

-- Set es una implementación existente en Haskell
mySet :: Set.Set Int
mySet = Set.fromList [1, 2, 3]

insertSet :: Int -> Set.Set Int -> Set.Set Int
insertSet = Set.insert

deleteSet :: Int -> Set.Set Int -> Set.Set Int
deleteSet = Set.delete

memberSet :: Int -> Set.Set Int -> Bool
memberSet = Set.member

isEmptySet :: Set.Set a -> Bool
isEmptySet = Set.null
4. Multiset (Conjunto Multicategoria)
Definición: Un multiconjunto permite la duplicación de elementos. Es una generalización del conjunto.

Operaciones principales:

insert: Añade un elemento al multiconjunto.
delete: Elimina una instancia de un elemento.
count: Devuelve el número de instancias de un elemento.
Ejemplo en Haskell:

haskell
Copiar código
import qualified Data.Map as Map

type Multiset a = Map.Map a Int

insertMulti :: Ord a => a -> Multiset a -> Multiset a
insertMulti x ms = Map.insertWith (+) x 1 ms

deleteMulti :: Ord a => a -> Multiset a -> Multiset a
deleteMulti x ms = case Map.lookup x ms of
  Just 1 -> Map.delete x ms
  Just n -> Map.insert x (n-1) ms
  Nothing -> ms

countMulti :: Ord a => a -> Multiset a -> Int
countMulti x ms = Map.findWithDefault 0 x ms
5. Map (Mapa)
Definición: Un mapa es una colección de pares clave-valor, donde cada clave es única.

Operaciones principales:

insert: Agrega un par clave-valor.
lookup: Busca el valor asociado a una clave.
delete: Elimina un par clave-valor.
Ejemplo en Haskell:

haskell
Copiar código
import qualified Data.Map as Map

type MyMap k v = Map.Map k v

insertMap :: Ord k => k -> v -> MyMap k v -> MyMap k v
insertMap = Map.insert

lookupMap :: Ord k => k -> MyMap k v -> Maybe v
lookupMap = Map.lookup

deleteMap :: Ord k => k -> MyMap k v -> MyMap k v
deleteMap = Map.delete
6. Priority Queue (Cola de Prioridad)
Definición: Una cola de prioridad es una estructura de datos donde cada elemento tiene una prioridad, y los elementos se eliminan según su prioridad en lugar de su orden de llegada.

Operaciones principales:

enqueue: Añade un elemento con una prioridad.
dequeue: Elimina el elemento con mayor prioridad.
Ejemplo en Haskell:

haskell
Copiar código
import qualified Data.List as List

data PriorityQueue a = PQ [(Int, a)] deriving Show

enqueuePQ :: Int -> a -> PriorityQueue a -> PriorityQueue a
enqueuePQ p x (PQ xs) = PQ ((p,x):xs)

dequeuePQ :: Ord a => PriorityQueue a -> (a, PriorityQueue a)
dequeuePQ (PQ xs) = let (p, x) = List.minimum xs in (x, PQ (filter (/= (p,x)) xs))
7. Heap (Montículo)
Definición: Un montículo es una estructura de datos que permite la implementación de una cola de prioridad eficiente. En un montículo, cada padre es mayor (en un montículo máximo) o menor (en un montículo mínimo) que sus hijos.

Operaciones principales:

insert: Añade un elemento al montículo.
extractMin o extractMax: Extrae el elemento mínimo o máximo.
Ejemplo en Haskell:

haskell
Copiar código
import qualified Data.Heap as Heap

type MyHeap a = Heap.MinHeap a

insertHeap :: Ord a => a -> MyHeap a -> MyHeap a
insertHeap = Heap.insert

extractMinHeap :: Ord a => MyHeap a -> (a, MyHeap a)
extractMinHeap h = case Heap.viewHead h of
  Just (x, h') -> (x, h')
  Nothing -> error "Heap is empty"
8. Binary Search Tree (Árbol de Búsqueda Binaria)
Definición: Un árbol de búsqueda binaria es un árbol donde cada nodo tiene un valor, y los valores de los nodos en el subárbol izquierdo son menores, mientras que los del subárbol derecho son mayores.

Operaciones principales:

insert: Inserta un nuevo valor.
search: Busca un valor.
delete: Elimina un valor.
Ejemplo en Haskell:

haskell
Copiar código
data BST a = Empty | Node a (BST a) (BST a) deriving Show

insertBST :: Ord a => a -> BST a -> BST a
insertBST x Empty = Node x Empty Empty
insertBST x (Node y left right)
  | x < y     = Node y (insertBST x left) right
  | otherwise = Node y left (insertBST x right)

searchBST :: Ord a => a -> BST a -> Bool
searchBST _ Empty = False
searchBST x (Node y left right)
  | x == y    = True
  | x < y     = searchBST x left
  | otherwise = searchBST x right
9. AVL Tree (Árbol AVL)
Definición: Un árbol AVL es un tipo de árbol de búsqueda binaria que se mantiene equilibrado. La altura de los subárboles izquierdo y derecho de cualquier nodo difiere en como máximo 1.

Operaciones principales:

insert: Inserta un nuevo valor y rebalancea.
delete: Elimina un valor y rebalancea.
Ejemplo en Haskell:

haskell
Copiar código
data AVL a = Empty | Node a (AVL a) (AVL a) Int deriving Show

-- La altura es parte del nodo
balance :: AVL a -> AVL a
balance (Node x left right h)
  | balanceFactor > 1 && height left >= height right = rotateRight (Node x left right h)
  | balanceFactor < -1 && height right >= height left = rotateLeft (Node x left right


Tú dijiste:
quiero explicaciones más profundas y detalladas con ejemplos más elaborados. No dejes fueras obviedades y  desarrolla todo lo que necesites, además se debe evaluar y el costo y la eficiencia de cada función o ejercicio que se realice
ChatGPT Plus
ChatGPT
¡Entendido! Vamos a profundizar en cada uno de los tipos abstractos de datos (TAD) en Haskell, brindando explicaciones más detalladas, ejemplos elaborados y una evaluación de costos y eficiencias.

1. Stack (Pila)
Concepto
La pila es una estructura de datos fundamental que opera bajo el principio LIFO (Last In, First Out). Imagina una pila de platos: el último plato que colocas es el primero que puedes sacar.

Operaciones
push: Agrega un elemento a la pila.
pop: Elimina el elemento superior de la pila.
peek: Muestra el elemento superior sin eliminarlo.
isEmpty: Verifica si la pila está vacía.
Implementación
haskell
Copiar código
data Stack a = Stack [a] deriving Show

-- Agregar un elemento
push :: a -> Stack a -> Stack a
push x (Stack xs) = Stack (x:xs)  -- O(1)

-- Eliminar el elemento superior
pop :: Stack a -> (a, Stack a)
pop (Stack (x:xs)) = (x, Stack xs)  -- O(1)

-- Mostrar el elemento superior
peek :: Stack a -> a
peek (Stack (x:_)) = x  -- O(1)

-- Verificar si está vacía
isEmpty :: Stack a -> Bool
isEmpty (Stack []) = True  -- O(1)
isEmpty _ = False
Costos y Eficiencia
Complejidad temporal: Todas las operaciones tienen complejidad O(1), lo que significa que son constantes y muy eficientes.
Complejidad espacial: O(n), donde n es el número de elementos en la pila.
Ejemplo
haskell
Copiar código
main :: IO ()
main = do
    let stack = Stack []
    let stack1 = push 1 stack
    let stack2 = push 2 stack1
    print $ peek stack2          -- Muestra 2
    let (top, stack3) = pop stack2
    print top                    -- Muestra 2
    print $ isEmpty stack3       -- Muestra False
2. Queue (Cola)
Concepto
Una cola opera bajo el principio FIFO (First In, First Out). Imagina una fila en un banco: la primera persona en llegar es la primera en ser atendida.

Operaciones
enqueue: Agrega un elemento al final de la cola.
dequeue: Elimina el primer elemento de la cola.
front: Muestra el primer elemento sin eliminarlo.
isEmpty: Verifica si la cola está vacía.
Implementación
haskell
Copiar código
data Queue a = Queue [a] [a] deriving Show

-- Agregar un elemento
enqueue :: a -> Queue a -> Queue a
enqueue x (Queue inQueue outQueue) = Queue (x:inQueue) outQueue  -- O(1)

-- Eliminar el primer elemento
dequeue :: Queue a -> (a, Queue a)
dequeue (Queue [] []) = error "Empty Queue"
dequeue (Queue inQueue (x:outQueue)) = (x, Queue inQueue outQueue)  -- O(1)
dequeue (Queue inQueue []) = dequeue (Queue [] (reverse inQueue))  -- O(n)

-- Mostrar el primer elemento
front :: Queue a -> a
front (Queue [] []) = error "Empty Queue"
front (Queue _ (x:outQueue)) = x  -- O(1)
front (Queue inQueue []) = head (reverse inQueue)  -- O(n)

-- Verificar si está vacía
isEmpty :: Queue a -> Bool
isEmpty (Queue [] []) = True  -- O(1)
isEmpty _ = False
Costos y Eficiencia
Complejidad temporal:
enqueue: O(1)
dequeue: O(1) en la mayoría de los casos, pero O(n) cuando se necesita invertir la lista.
front: O(1) o O(n) dependiendo de la implementación.
Complejidad espacial: O(n), donde n es el número de elementos en la cola.
Ejemplo
haskell
Copiar código
main :: IO ()
main = do
    let queue = Queue [] []
    let queue1 = enqueue 1 queue
    let queue2 = enqueue 2 queue1
    print $ front queue2          -- Muestra 1
    let (first, queue3) = dequeue queue2
    print first                   -- Muestra 1
    print $ isEmpty queue3        -- Muestra False
3. Set (Conjunto)
Concepto
Un conjunto es una colección de elementos únicos, donde el orden no importa. Permite realizar operaciones de pertenencia de manera eficiente.

Operaciones
insert: Añade un elemento al conjunto.
delete: Elimina un elemento del conjunto.
member: Verifica si un elemento pertenece al conjunto.
isEmpty: Verifica si el conjunto está vacío.
Implementación
Usaremos la biblioteca Data.Set de Haskell, que utiliza árboles balanceados.

haskell
Copiar código
import qualified Data.Set as Set

type MySet a = Set.Set a

-- Insertar un elemento
insertSet :: Ord a => a -> MySet a -> MySet a
insertSet = Set.insert  -- O(log n)

-- Eliminar un elemento
deleteSet :: Ord a => a -> MySet a -> MySet a
deleteSet = Set.delete  -- O(log n)

-- Verificar si pertenece
memberSet :: Ord a => a -> MySet a -> Bool
memberSet = Set.member  -- O(log n)

-- Verificar si está vacío
isEmptySet :: MySet a -> Bool
isEmptySet = Set.null  -- O(1)
Costos y Eficiencia
Complejidad temporal: O(log n) para insert, delete, y member debido a la estructura de árbol.
Complejidad espacial: O(n).
Ejemplo
haskell
Copiar código
main :: IO ()
main = do
    let mySet = Set.empty
    let mySet1 = insertSet 1 mySet
    let mySet2 = insertSet 2 mySet1
    print $ memberSet 1 mySet2      -- Muestra True
    let mySet3 = deleteSet 1 mySet2
    print $ memberSet 1 mySet3      -- Muestra False
    print $ isEmptySet mySet3       -- Muestra False
4. Multiset (Conjunto Multicategoria)
Concepto
Un multiconjunto permite la duplicación de elementos. Es útil cuando necesitas contar la frecuencia de elementos.

Operaciones
insert: Añade un elemento (incrementa su conteo).
delete: Elimina una instancia de un elemento.
count: Devuelve el número de instancias de un elemento.
Implementación
haskell
Copiar código
import qualified Data.Map as Map

type Multiset a = Map.Map a Int

-- Insertar un elemento
insertMulti :: Ord a => a -> Multiset a -> Multiset a
insertMulti x ms = Map.insertWith (+) x 1 ms  -- O(log n)

-- Eliminar un elemento
deleteMulti :: Ord a => a -> Multiset a -> Multiset a
deleteMulti x ms = case Map.lookup x ms of
  Just 1 -> Map.delete x ms  -- O(log n)
  Just n -> Map.insert x (n-1) ms  -- O(log n)
  Nothing -> ms  -- O(log n)

-- Contar instancias de un elemento
countMulti :: Ord a => a -> Multiset a -> Int
countMulti x ms = Map.findWithDefault 0 x ms  -- O(log n)
Costos y Eficiencia
Complejidad temporal: O(log n) para insert, delete, y count.
Complejidad espacial: O(n).
Ejemplo
haskell
Copiar código
main :: IO ()
main = do
    let multiSet = Map.empty
    let multiSet1 = insertMulti 'a' multiSet
    let multiSet2 = insertMulti 'a' multiSet1
    let multiSet3 = insertMulti 'b' multiSet2
    print $ countMulti 'a' multiSet3   -- Muestra 2
    let multiSet4 = deleteMulti 'a' multiSet3
    print $ countMulti 'a' multiSet4   -- Muestra 1
5. Map (Mapa)
Concepto
Un mapa es una colección de pares clave-valor, donde cada clave es única. Permite acceder a valores de manera eficiente a través de su clave.

Operaciones
insert: Agrega un par clave-valor.
lookup: Busca el valor asociado a una clave.
delete: Elimina un par clave-valor.
Implementación
haskell
Copiar código
import qualified Data.Map as Map

type MyMap k v = Map.Map k v

-- Insertar un par clave-valor
insertMap :: Ord k => k -> v -> MyMap k v -> MyMap k v
insertMap = Map.insert  -- O(log n)

-- Buscar un valor por clave
lookupMap :: Ord k => k -> MyMap k v -> Maybe v
lookupMap = Map.lookup  -- O(log n)

-- Eliminar un par clave-valor
deleteMap :: Ord k => k -> MyMap k v -> MyMap k v
deleteMap = Map.delete  -- O(log n)
Costos y Eficiencia
Complejidad temporal: O(log n) para insert, lookup, y delete.
Complejidad espacial: O(n).
Ejemplo
haskell
Copiar código
main :: IO ()
main = do
    let myMap = Map.empty
    let myMap1 = insertMap "a" 1 myMap
    let myMap2 = insertMap "b" 2 myMap1
    print $ lookupMap "a" myMap2     -- Muestra Just 1
    let myMap3 = deleteMap "a" myMap2
    print $ lookupMap "a" myMap3     -- Muestra Nothing
6. Priority Queue (Cola de Prioridad)
Concepto
Una cola de prioridad es una estructura de datos donde cada elemento tiene una prioridad. Los elementos se eliminan en función de su prioridad en lugar de su orden de llegada.

Operaciones
enqueue: Añade un elemento con una prioridad.
dequeue: Extrae el elemento con mayor prioridad.
Implementación
Podemos usar una lista ordenada para implementar una cola de prioridad simple.

haskell
Copiar código
import qualified Data.List as List

data PriorityQueue a = PQ [(Int, a)] deriving Show

-- Agregar un elemento
enqueue :: Int -> a -> PriorityQueue a -> PriorityQueue a
enqueue p x (PQ xs) = PQ ((p,x):xs)  -- O(1)

-- Extraer el elemento de mayor prioridad
dequeue :: Ord a => PriorityQueue a -> (a, PriorityQueue a)
dequeue (PQ xs) = let (p, x) = List.minimumBy (compare `on` fst) xs in (x, PQ (filter (/= (p,x)) xs))  -- O(n)
Costos y Eficiencia
Complejidad temporal:
enqueue: O(1) (si lo agregamos al final de la lista).
dequeue: O(n) (debemos encontrar el mínimo).
Complejidad espacial: O(n).
Ejemplo
haskell
Copiar código
main :: IO ()
main = do
    let pq = PQ []
    let pq1 = enqueue 3 "low" pq
    let pq2 = enqueue 1 "high" pq1
    let pq3 = enqueue 2 "medium" pq2
    let (item, pq4) = dequeue pq3
    print item                -- Muestra ("high", 1)
7. Heap (Montículo)
Concepto
Un montículo es una estructura de datos que permite implementar una cola de prioridad de manera eficiente. Existen dos tipos: montículo máximo (el padre es mayor que los hijos) y montículo mínimo (el padre es menor que los hijos).

Operaciones
insert: Añade un elemento al montículo.
extractMin o extractMax: Extrae el elemento mínimo o máximo.
Implementación
Utilizaremos la biblioteca Data.Heap para un montículo mínimo.

haskell
Copiar código
import qualified Data.Heap as Heap

type MyHeap a = Heap.MinHeap a

-- Insertar un elemento
insertHeap :: Ord a => a -> MyHeap a -> MyHeap a
insertHeap = Heap.insert  -- O(log n)

-- Extraer el mínimo
extractMinHeap :: Ord a => MyHeap a -> (a, MyHeap a)
extractMinHeap h = case Heap.viewHead h of
    Just (x, h') -> (x, h')
    Nothing -> error "Heap is empty"
Costos y Eficiencia
Complejidad temporal: O(log n) para insert y extractMin.
Complejidad espacial: O(n).
Ejemplo
haskell
Copiar código
main :: IO ()
main = do
    let heap = Heap.empty
    let heap1 = insertHeap 5 heap
    let heap2 = insertHeap 3 heap1
    let heap3 = insertHeap 8 heap2
    let (minElem, heap4) = extractMinHeap heap3
    print minElem           -- Muestra 3
8. Binary Search Tree (Árbol de Búsqueda Binaria)
Concepto
Un árbol de búsqueda binaria (BST) es una estructura de datos en forma de árbol donde cada nodo tiene un valor, y el valor del subárbol izquierdo es menor que el nodo, y el valor del subárbol derecho es mayor.

Operaciones
insert: Inserta un nuevo valor.
search: Busca un valor.
delete: Elimina un valor.
Implementación
haskell
Copiar código
data BST a = Empty | Node a (BST a) (BST a) deriving Show

-- Insertar un valor
insertBST :: Ord a => a -> BST a -> BST a
insertBST x Empty = Node x Empty Empty
insertBST x (Node y left right)
  | x < y     = Node y (insertBST x left) right  -- O(log n) en promedio, O(n) en el peor caso
  | otherwise = Node y left (insertBST x right)

-- Buscar un valor
searchBST :: Ord a => a -> BST a -> Bool
searchBST _ Empty = False
searchBST x (Node y left right)
  | x == y    = True
  | x < y     = searchBST x left  -- O(log n) en promedio, O(n) en el peor caso
  | otherwise = searchBST x right
Costos y Eficiencia
Complejidad temporal:
insert: O(log n) en promedio, O(n) en el peor caso (árbol desbalanceado).
search: O(log n) en promedio, O(n) en el peor caso.
Complejidad espacial: O(n).
Ejemplo
haskell
Copiar código
main :: IO ()
main = do
    let bst = Empty
    let bst1 = insertBST 5 bst
    let bst2 = insertBST 3 bst1
    let bst3 = insertBST 7 bst2
    print $ searchBST 3 bst3    -- Muestra True
    print $ searchBST 8 bst3    -- Muestra False
9. AVL Tree (Árbol AVL)
Concepto
Un árbol AVL es un tipo de árbol de búsqueda binaria que se mantiene equilibrado. La altura de los subárboles izquierdo y derecho de cualquier nodo no difiere en más de 1, lo que asegura operaciones eficientes.

Operaciones
insert: Inserta un nuevo valor y rebalancea el árbol.
delete: Elimina un valor y rebalancea el árbol.
Implementación
haskell
Copiar código
data AVL a = Empty | Node a (AVL a) (AVL a) Int deriving Show  -- La altura es parte del nodo

-- Función para obtener la altura
height :: AVL a -> Int
height Empty = 0
height (Node _ _ _ h) = h

-- Función para obtener el factor de equilibrio
balanceFactor :: AVL a -> Int
balanceFactor Empty = 0
balanceFactor (Node _ left right _) = height left - height right

-- Rotaciones para balancear el árbol
rotateRight :: AVL a -> AVL a
rotateRight (Node x (Node y left right) rightSubtree _) = Node y left (Node x right rightSubtree (height rightSubtree + 1)) (max (height left) (height rightSubtree) + 1)

rotateLeft :: AVL a -> AVL a
rotateLeft (Node x left (Node y leftSubtree right) _) = Node y (Node x left leftSubtree (max (height left) (height leftSubtree) + 1)) right (max (height leftSubtree) (height right) + 1)

-- Insertar y balancear el árbol
insertAVL :: Ord a => a -> AVL a -> AVL a
insertAVL x Empty = Node x Empty Empty 1
insertAVL x (Node y left right _)
  | x < y     = let left' = insertAVL x left in balance (Node y left' right (1 + max (height left') (height right)))
  | otherwise = let right' = insertAVL x right in balance (Node y left right' (1 + max (height left) (height right')))

-- Balancear el árbol después de la inserción
balance :: AVL a -> AVL a
balance node@(Node _ left right _)
  | balanceFactor node > 1 = if balanceFactor left < 0 then rotateRight (Node (root left) (rotateLeft left) right (height node)) else rotateRight node
  | balanceFactor node < -1 = if balanceFactor right > 0 then rotateLeft (Node (root right) left (rotateRight right) (height node)) else rotateLeft node
  | otherwise = node

-- Obtener la raíz de un nodo
root :: AVL a -> a
root (Node x _ _ _) = x

-- ... (agregar funciones de eliminación y demás operaciones)
Costos y Eficiencia
Complejidad temporal:
insert: O(log n) para insertar y balancear.
delete: O(log n) para eliminar y balancear.
Complejidad espacial: O(n).
Ejemplo
haskell
Copiar código
main :: IO ()
main = do
    let avl = Empty
    let avl1 = insertAVL 10 avl
    let avl2 = insertAVL 20 avl1
    let avl3 = insertAVL 30 avl2
    print avl3  -- Muestra el árbol balanceado
Resumen
Hemos cubierto diferentes tipos abstractos de datos en Haskell, incluyendo su implementación, eficiencia y ejemplos prácticos. Es fundamental entender tanto las operaciones como los costos asociados para elegir la estructura adecuada para cada situación. Si necesitas más detalles sobre alguna estructura específica o más ejemplos, ¡no dudes en preguntar!



Tú dijiste:
Quiero la misma explicación pero con comentarios donde corresponda, marcando las recursiones y decisiones q se realizan etc
ChatGPT Plus
ChatGPT
Claro, a continuación te presento una explicación más detallada y comentada de los tipos abstractos de datos en Haskell, con un enfoque en la claridad de las decisiones y recursiones involucradas.

1. Stack (Pila)
Concepto
La pila es una estructura LIFO (Last In, First Out). El último elemento agregado es el primero en ser eliminado.

Implementación
haskell
Copiar código
data Stack a = Stack [a] deriving Show

-- Agregar un elemento a la pila
push :: a -> Stack a -> Stack a
push x (Stack xs) = Stack (x:xs)  -- O(1)

-- Eliminar el elemento superior de la pila
pop :: Stack a -> (a, Stack a)
pop (Stack (x:xs)) = (x, Stack xs)  -- O(1)

-- Mostrar el elemento superior sin eliminarlo
peek :: Stack a -> a
peek (Stack (x:_)) = x  -- O(1)

-- Verificar si la pila está vacía
isEmpty :: Stack a -> Bool
isEmpty (Stack []) = True  -- O(1)
isEmpty _ = False
Ejemplo de Uso
haskell
Copiar código
main :: IO ()
main = do
    let stack = Stack []  -- Crear una pila vacía
    let stack1 = push 1 stack  -- Push 1
    let stack2 = push 2 stack1  -- Push 2
    print $ peek stack2  -- Muestra 2
    let (top, stack3) = pop stack2  -- Pop: elimina 2
    print top  -- Muestra 2
    print $ isEmpty stack3  -- Muestra False
2. Queue (Cola)
Concepto
Una cola opera bajo el principio FIFO (First In, First Out). El primer elemento agregado es el primero en ser eliminado.

Implementación
haskell
Copiar código
data Queue a = Queue [a] [a] deriving Show

-- Agregar un elemento al final de la cola
enqueue :: a -> Queue a -> Queue a
enqueue x (Queue inQueue outQueue) = Queue (x:inQueue) outQueue  -- O(1)

-- Eliminar el primer elemento de la cola
dequeue :: Queue a -> (a, Queue a)
dequeue (Queue [] []) = error "Empty Queue"  -- Manejo de cola vacía
dequeue (Queue inQueue (x:outQueue)) = (x, Queue inQueue outQueue)  -- O(1)
dequeue (Queue inQueue []) = dequeue (Queue [] (reverse inQueue))  -- O(n) cuando se necesita invertir

-- Mostrar el primer elemento sin eliminarlo
front :: Queue a -> a
front (Queue [] []) = error "Empty Queue"  -- Manejo de cola vacía
front (Queue _ (x:outQueue)) = x  -- O(1)
front (Queue inQueue []) = head (reverse inQueue)  -- O(n)

-- Verificar si la cola está vacía
isEmpty :: Queue a -> Bool
isEmpty (Queue [] []) = True  -- O(1)
isEmpty _ = False
Ejemplo de Uso
haskell
Copiar código
main :: IO ()
main = do
    let queue = Queue [] []  -- Crear una cola vacía
    let queue1 = enqueue 1 queue  -- Enqueue 1
    let queue2 = enqueue 2 queue1  -- Enqueue 2
    print $ front queue2  -- Muestra 1
    let (first, queue3) = dequeue queue2  -- Dequeue: elimina 1
    print first  -- Muestra 1
    print $ isEmpty queue3  -- Muestra False
3. Set (Conjunto)
Concepto
Un conjunto es una colección de elementos únicos. Utiliza un árbol balanceado para optimizar las operaciones.

Implementación
Utilizaremos la biblioteca Data.Set:

haskell
Copiar código
import qualified Data.Set as Set

type MySet a = Set.Set a

-- Insertar un elemento
insertSet :: Ord a => a -> MySet a -> MySet a
insertSet = Set.insert  -- O(log n)

-- Eliminar un elemento
deleteSet :: Ord a => a -> MySet a -> MySet a
deleteSet = Set.delete  -- O(log n)

-- Verificar si pertenece
memberSet :: Ord a => a -> MySet a -> Bool
memberSet = Set.member  -- O(log n)

-- Verificar si está vacío
isEmptySet :: MySet a -> Bool
isEmptySet = Set.null  -- O(1)
Ejemplo de Uso
haskell
Copiar código
main :: IO ()
main = do
    let mySet = Set.empty  -- Crear un conjunto vacío
    let mySet1 = insertSet 1 mySet  -- Insertar 1
    let mySet2 = insertSet 2 mySet1  -- Insertar 2
    print $ memberSet 1 mySet2  -- Muestra True
    let mySet3 = deleteSet 1 mySet2  -- Eliminar 1
    print $ memberSet 1 mySet3  -- Muestra False
    print $ isEmptySet mySet3  -- Muestra False
4. Multiset (Conjunto Multicategoria)
Concepto
Un multiconjunto permite elementos duplicados y lleva un conteo de las instancias.

Implementación
haskell
Copiar código
import qualified Data.Map as Map

type Multiset a = Map.Map a Int

-- Insertar un elemento (incrementa su conteo)
insertMulti :: Ord a => a -> Multiset a -> Multiset a
insertMulti x ms = Map.insertWith (+) x 1 ms  -- O(log n)

-- Eliminar un elemento (decrementa su conteo)
deleteMulti :: Ord a => a -> Multiset a -> Multiset a
deleteMulti x ms = case Map.lookup x ms of
  Just 1 -> Map.delete x ms  -- Si sólo queda una instancia, la eliminamos (O(log n))
  Just n -> Map.insert x (n-1) ms  -- Decrementamos el conteo (O(log n))
  Nothing -> ms  -- Si no existe, retornamos el mismo multiconjunto (O(log n))

-- Contar instancias de un elemento
countMulti :: Ord a => a -> Multiset a -> Int
countMulti x ms = Map.findWithDefault 0 x ms  -- O(log n)
Ejemplo de Uso
haskell
Copiar código
main :: IO ()
main = do
    let multiSet = Map.empty  -- Crear un multiconjunto vacío
    let multiSet1 = insertMulti 'a' multiSet  -- Insertar 'a'
    let multiSet2 = insertMulti 'a' multiSet1  -- Insertar otra 'a'
    let multiSet3 = insertMulti 'b' multiSet2  -- Insertar 'b'
    print $ countMulti 'a' multiSet3  -- Muestra 2
    let multiSet4 = deleteMulti 'a' multiSet3  -- Eliminar una 'a'
    print $ countMulti 'a' multiSet4  -- Muestra 1
5. Map (Mapa)
Concepto
Un mapa es una colección de pares clave-valor donde las claves son únicas.

Implementación
haskell
Copiar código
import qualified Data.Map as Map

type MyMap k v = Map.Map k v

-- Insertar un par clave-valor
insertMap :: Ord k => k -> v -> MyMap k v -> MyMap k v
insertMap = Map.insert  -- O(log n)

-- Buscar un valor por clave
lookupMap :: Ord k => k -> MyMap k v -> Maybe v
lookupMap = Map.lookup  -- O(log n)

-- Eliminar un par clave-valor
deleteMap :: Ord k => k -> MyMap k v -> MyMap k v
deleteMap = Map.delete  -- O(log n)
Ejemplo de Uso
haskell
Copiar código
main :: IO ()
main = do
    let myMap = Map.empty  -- Crear un mapa vacío
    let myMap1 = insertMap "a" 1 myMap  -- Insertar par ("a", 1)
    let myMap2 = insertMap "b" 2 myMap1  -- Insertar par ("b", 2)
    print $ lookupMap "a" myMap2  -- Muestra Just 1
    let myMap3 = deleteMap "a" myMap2  -- Eliminar par con clave "a"
    print $ lookupMap "a" myMap3  -- Muestra Nothing
6. Priority Queue (Cola de Prioridad)
Concepto
Una cola de prioridad permite insertar elementos con una prioridad asignada, y los elementos se extraen según su prioridad.

Implementación
haskell
Copiar código
import qualified Data.List as List

data PriorityQueue a = PQ [(Int, a)] deriving Show

-- Agregar un elemento con prioridad
enqueue :: Int -> a -> PriorityQueue a -> PriorityQueue a
enqueue p x (PQ xs) = PQ ((p,x):xs)  -- O(1)

-- Extraer el elemento de mayor prioridad
dequeue :: Ord a => PriorityQueue a -> (a, PriorityQueue a)
dequeue (PQ xs) = let (p, x) = List.minimumBy (compare `on` fst) xs in (x, PQ (filter (/= (p,x)) xs))  -- O(n)
Ejemplo de Uso
haskell
Copiar código
main :: IO ()
main = do
    let pq = PQ []  -- Crear una cola de prioridad vacía
    let pq1 = enqueue 3 "low" pq  -- Agregar "low" con prioridad 3
    let pq2 = enqueue 1 "high" pq1  -- Agregar "high" con prioridad 1
    let pq3 = enqueue 2 "medium" pq2  -- Agregar "medium" con prioridad 2
    let (item, pq4) = dequeue pq3  -- Extraer el elemento con mayor prioridad
    print item  -- Muestra "high"
7. Heap (Montículo)
Concepto
Un montículo es una estructura que permite implementar una cola de prioridad eficientemente. Puede ser un montículo mínimo o máximo.

Implementación
haskell
Copiar código
import qualified Data.Heap as Heap

type MyHeap a = Heap.MinHeap a

-- Insertar un elemento
insertHeap :: Ord a => a -> MyHeap a -> MyHeap a
insertHeap = Heap.insert  -- O(log n)

-- Extraer el mínimo
extractMinHeap :: Ord a => MyHeap a -> (a, MyHeap a)
extractMinHeap h = case Heap.viewHead h of
    Just (x, h') -> (x, h')
    Nothing -> error "Heap is empty"  -- Manejo de heap vacío
Ejemplo de Uso
haskell
Copiar código
main :: IO ()
main = do
    let heap = Heap.empty  -- Crear un heap vacío
    let heap1 = insertHeap 5 heap  -- Insertar 5
    let heap2 = insertHeap 3 heap1  -- Insertar 3
    let heap3 = insertHeap 8 heap2  -- Insertar 8
    let (minElem, heap4) = extractMinHeap heap3  -- Extraer el mínimo
    print minElem  -- Muestra 3
8. Binary Search Tree (Árbol de Búsqueda Binaria)
Concepto
Un BST organiza sus nodos de forma que cada nodo tenga un valor mayor que todos sus nodos en el subárbol izquierdo y menor en el subárbol derecho.

Implementación
haskell
Copiar código
data BST a = Empty | Node a (BST a) (BST a) deriving Show

-- Insertar un valor
insertBST :: Ord a => a -> BST a -> BST a
insertBST x Empty = Node x Empty Empty  -- Si el árbol está vacío, crear un nuevo nodo
insertBST x (Node y left right)
  | x < y     = Node y (insertBST x left) right  -- Insertar en el subárbol izquierdo
  | otherwise = Node y left (insertBST x right)  -- Insertar en el subárbol derecho

-- Buscar un valor
searchBST :: Ord a => a -> BST a -> Bool
searchBST _ Empty = False  -- Si está vacío, no se encuentra
searchBST x (Node y left right)
  | x == y    = True  -- Se encontró el valor
  | x < y     = searchBST x left  -- Buscar en el subárbol izquierdo
  | otherwise = searchBST x right  -- Buscar en el subárbol derecho
Ejemplo de Uso
haskell
Copiar código
main :: IO ()
main = do
    let bst = Empty  -- Crear un árbol vacío
    let bst1 = insertBST 5 bst  -- Insertar 5
    let bst2 = insertBST 3 bst1  -- Insertar 3
    let bst3 = insertBST 7 bst2  -- Insertar 7
    print $ searchBST 3 bst3  -- Muestra True
    print $ searchBST 8 bst3  -- Muestra False
9. AVL Tree (Árbol AVL)
Concepto
Un árbol AVL es un árbol de búsqueda binaria que se mantiene equilibrado, garantizando que las alturas de los subárboles no difieran en más de uno.

Implementación
haskell
Copiar código
data AVL a = Empty | Node a (AVL a) (AVL a) Int deriving Show  -- Int es la altura

-- Obtener la altura
height :: AVL a -> Int
height Empty = 0  -- La altura de un árbol vacío es 0
height (Node _ _ _ h) = h  -- Devolver la altura almacenada

-- Obtener el factor de equilibrio
balanceFactor :: AVL a -> Int
balanceFactor Empty = 0  -- Un árbol vacío tiene un factor de equilibrio de 0
balanceFactor (Node _ left right _) = height left - height right  -- Altura izquierda - Altura derecha

-- Rotación a la derecha
rotateRight :: AVL a -> AVL a
rotateRight (Node x (Node y left right) rightSubtree _) = 
    Node y left (Node x right rightSubtree (height rightSubtree + 1)) (max (height left) (height rightSubtree) + 1)

-- Rotación a la izquierda
rotateLeft :: AVL a -> AVL a
rotateLeft (Node x left (Node y leftSubtree right) _) = 
    Node y (Node x left leftSubtree (max (height left) (height leftSubtree) + 1)) right (max (height leftSubtree) (height right) + 1)

-- Insertar y balancear el árbol
insertAVL :: Ord a => a -> AVL a -> AVL a
insertAVL x Empty = Node x Empty Empty 1  -- Crear un nuevo nodo si el árbol está vacío
insertAVL x (Node y left right _)
  | x < y     = let left' = insertAVL x left in balance (Node y left' right (1 + max (height left') (height right)))  -- Insertar en el subárbol izquierdo
  | otherwise = let right' = insertAVL x right in balance (Node y left right' (1 + max (height left) (height right')))  -- Insertar en el subárbol derecho

-- Balancear el árbol después de la inserción
balance :: AVL a -> AVL a
balance node@(Node _ left right _)
  | balanceFactor node > 1 = if balanceFactor left < 0 
                               then rotateRight (Node (root left) (rotateLeft left) right (height node)) 
                               else rotateRight node  -- Rotación simple a la derecha
  | balanceFactor node < -1 = if balanceFactor right > 0 
                                then rotateLeft (Node (root right) left (rotateRight right) (height node)) 
                                else rotateLeft node  -- Rotación simple a la izquierda
  | otherwise = node  -- Si está balanceado, devolver el nodo sin cambios

-- Obtener la raíz de un nodo
root :: AVL a -> a
root (Node x _ _ _) = x  -- Devolver el valor del nodo
Ejemplo de Uso
haskell
Copiar código
main :: IO ()
main = do
    let avl = Empty  -- Crear un árbol AVL vacío
    let avl1 = insertAVL 10 avl  -- Insertar 10
    let avl2 = insertAVL 20 avl1  -- Insertar 20
    let avl3 = insertAVL 30 avl2  -- Insertar 30 (causa rotación)
    print avl3  -- Muestra el árbol balanceado
Resumen
A lo largo de esta guía, hemos cubierto diversas estructuras de datos en Haskell, sus implementaciones, y hemos añadido comentarios detallados para clarificar las decisiones y procesos recursivos. Si necesitas más información o ejemplos adicionales sobre alguna de estas estructuras, ¡estaré encantado de ayudarte!